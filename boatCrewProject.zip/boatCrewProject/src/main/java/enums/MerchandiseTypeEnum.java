package enums;

public enum MerchandiseTypeEnum {
    FOOD,
    MATERIAL,
    WEAPON,
    FABRIC,
    SPICE
}

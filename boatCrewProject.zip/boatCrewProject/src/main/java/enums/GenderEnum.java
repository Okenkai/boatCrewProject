package enums;

public enum GenderEnum {
    MALE, FEMALE
}
